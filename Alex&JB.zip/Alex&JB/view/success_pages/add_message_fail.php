<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <link rel="stylesheet" type="text/css" href="#">
    <link rel="icon"  href="view/PageAccueil/favicon/favicon-16x16.png" type="image/png" sizes="any">
    <title>MeerCast</title>
</head>

<body>
	<h1>L'envoie de votre message est un echec</h1>
	<h2>C'est surement parce que notre serveur est en maintenance, veuillez rééssayer plus tard...</h2>

</body>
</html>