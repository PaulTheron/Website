<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <link rel="stylesheet" type="text/css" href="#">
    <link rel="icon"  href="view/PageAccueil/favicon/favicon-16x16.png" type="image/png" sizes="any">
    <title>MeerCast</title>
</head>

<body>
	<h1>L'envoie de votre message est un succés</h1>
	<h2>Votre message à été stocké dans notre base de donnée, un administrateur va donc se lever, prendre son ordinateur et lire votre message, si ce dernier est intéressant, il va y répondre par mail, et vous serais content.
	Pour revenir sur notre page d'acceuil, vous pouvez revenir en arrière.</h2>

</body>
</html>