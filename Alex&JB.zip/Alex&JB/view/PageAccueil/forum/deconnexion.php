<?php 
session_unset();
session_destroy();

require  "view/PageAccueil/forum/forum.php";


 ?>